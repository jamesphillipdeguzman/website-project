### Welcome to FoodExer!

**FoodExer** is a personal project I'm currently developing as part of my **WDD330 - Web and Frontend Development II** course. The website aims to bring together the concepts of healthy eating and fitness in an interactive way.

Please note, the site is still under construction, and I appreciate your patience as I work on refining and adding new features.

You can explore the current version of the site at the following **Netlify** production URL:  
[**FoodExer on Netlify**](https://foodexer.netlify.app/)
